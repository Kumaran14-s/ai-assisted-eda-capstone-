# AI-Assisted Exploratory Data Analysis on an Open Dataset

A beginner-friendly CSE capstone demonstrating a transparent EDA workflow using Python, Pandas, NumPy, Matplotlib, Seaborn, Plotly and Streamlit.

## Features
- CSV upload and offline demo data
- Data preview, descriptive statistics, data types and unique-value counts
- Missing-value and duplicate-row checks
- IQR-based potential-outlier diagnostics
- Interactive distribution, scatter, correlation heatmap, grouped box plot and category-count charts
- Optional cleaning with a log and before/after comparison
- Cleaned CSV and data-quality summary downloads
- Notebook, tests, research/ethics notes, quiz, prompt library, report and 6-slide presentation

## Quick start
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app.py
```

Run automated tests:
```bash
python -m unittest discover -s tests -v
```

Run notebook:
```bash
jupyter notebook notebooks/eda_analysis.ipynb
```

## Data integrity
The bundled `data/sample_penguins_demo.csv` is a small **synthetic teaching sample** created for offline demonstration. It is not official Palmer Penguins data and must not be cited as field research. For a formal analysis, download the official public dataset from the source described in `docs/DATASET_NOTE.md`, preserve the source file unchanged, record its exact version/download date and licence, and upload it to the app.

## Responsible use
Do not upload private or personally identifiable data. Inspect every suggested cleaning change. IQR outliers are only flags. Correlation is not causation. The dashboard does not make AI API calls; AI is used only as an optional workflow/research topic and its outputs must be independently verified.

## Repository layout
- `app.py` — Streamlit application
- `src/eda_utils.py` — testable data-quality and cleaning functions
- `data/` — offline demo dataset
- `notebooks/` — reproducible notebook
- `reports/` — report and verification notes
- `presentation/` — slide content and generated PPTX
- `docs/` — dataset note, checklist, prompt library, quiz and demo guide
- `tests/` — unit tests

## Capstone completion checklist
See `docs/DATA_QUALITY_CHECKLIST.md` and `reports/VERIFICATION_REPORT.md`. Run tests and verify the app in your own environment before submission.
