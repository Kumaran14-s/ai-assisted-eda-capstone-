# EDA quiz (10 questions)

1. What does EDA stand for? A) Exploratory Data Analysis B) External Data Algorithm C) Estimated Dataset Average D) Easy Data App
2. Which Pandas method counts missing values by column? A) `isna().sum()` B) `sort_values()` C) `rename()` D) `head()`
3. Why should the original dataset be preserved? A) To compare and reproduce changes B) To increase file size C) To remove all uncertainty D) To avoid testing
4. Does correlation prove causation? A) Yes B) No
5. What does `DataFrame.duplicated()` help identify? A) Exact repeated rows B) All incorrect values C) Causal effects D) Licence terms
6. What is an IQR outlier rule? A) A diagnostic based on quartiles B) Proof of an error C) A missing-value replacement D) A chart type
7. Why document the dataset licence? A) To understand permitted use and obligations B) To calculate the mean C) To fix data types D) To hide the source
8. Which chart is commonly useful for a numeric distribution? A) Histogram B) Sitemap C) Flowchart D) Gantt chart
9. What is median imputation? A) Replacing missing numeric values with the column median B) Removing all columns C) Sorting rows D) Removing categories
10. What should happen before reporting an AI-generated numeric claim? A) Verify it against calculations/source B) Assume it is correct C) Remove the source D) Present it as causal evidence

## Answer key
1-A, 2-A, 3-A, 4-B, 5-A, 6-A, 7-A, 8-A, 9-A, 10-A.
