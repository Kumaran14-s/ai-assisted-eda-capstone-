# Final demo guide (5–7 minutes)

1. **Introduction (30 sec):** explain the goal: help analysts inspect a dataset while verifying every result.
2. **Dataset (45 sec):** show the offline synthetic sample; explicitly distinguish it from official Palmer Penguins data.
3. **Quality checks (60 sec):** demonstrate missing cells, duplicate rows, dtypes and IQR flags.
4. **Charts (90 sec):** show a histogram, scatter plot, correlation heatmap, grouped box plot and category-count chart.
5. **Cleaning (60 sec):** select a cleaning option; compare before/after rows and missing cells; download the output.
6. **Verification (45 sec):** show unit tests, notebook and checklist.
7. **Ethics/limitations (45 sec):** explain missingness, outlier caution, licence checks and correlation-not-causation.
8. **Close:** state next step: rerun the workflow on a verified official open dataset.

Before presenting: install dependencies, run tests, open the app locally, and replace illustrative findings with results from the actual research dataset.
