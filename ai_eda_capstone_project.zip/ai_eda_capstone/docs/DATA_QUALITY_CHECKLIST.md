# Data-quality checklist

- [ ] Record dataset name, source URL, download date, version and licence.
- [ ] Confirm row/column counts and whether each row represents one observation.
- [ ] Inspect column names, data types, units and allowed ranges.
- [ ] Count missing cells per column and investigate the reason where metadata permits.
- [ ] Count exact duplicate rows; decide whether duplicates are valid repeated observations.
- [ ] Check category spelling, leading/trailing whitespace and inconsistent labels.
- [ ] Inspect numeric distributions and IQR outlier flags; do not delete automatically.
- [ ] Validate calculations using a second method or hand-check a sample.
- [ ] Save original data unchanged and document every transformation.
- [ ] Compare row counts, missingness and key statistics before and after cleaning.
- [ ] Verify charts use the intended columns and exclude/label missing values clearly.
- [ ] Avoid causal claims from descriptive statistics or correlation.
- [ ] Ensure no personal or confidential data is included.
- [ ] Record tests run, software versions and unresolved limitations.
