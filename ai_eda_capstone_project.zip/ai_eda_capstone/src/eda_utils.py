"""Small, transparent helper functions for exploratory data analysis."""
import pandas as pd

def data_quality_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Return one row per column with missingness, uniqueness and dtype."""
    n = len(df)
    rows = []
    for col in df.columns:
        missing = int(df[col].isna().sum())
        rows.append({
            "column": col,
            "dtype": str(df[col].dtype),
            "non_missing": int(df[col].notna().sum()),
            "missing_count": missing,
            "missing_percent": round((missing / n * 100) if n else 0.0, 2),
            "unique_values": int(df[col].nunique(dropna=True)),
        })
    return pd.DataFrame(rows)

def clean_dataframe(df: pd.DataFrame, drop_duplicates=False,
                    missing_action="Keep unchanged", trim_text=True):
    """Clean a copy and return it with a human-readable change log."""
    result = df.copy(deep=True)
    log = {"Input rows": len(result), "Input missing cells": int(result.isna().sum().sum())}
    if trim_text:
        for col in result.select_dtypes(include=["object", "string"]).columns:
            result[col] = result[col].map(lambda x: x.strip() if isinstance(x, str) else x)
    log["Whitespace trimming"] = "Applied" if trim_text else "Not applied"
    if drop_duplicates:
        before = len(result)
        result = result.drop_duplicates().reset_index(drop=True)
        log["Duplicate rows removed"] = before - len(result)
    else:
        log["Duplicate rows removed"] = 0
    if missing_action == "Drop rows with missing values":
        before = len(result)
        result = result.dropna().reset_index(drop=True)
        log["Rows removed for missing values"] = before - len(result)
    elif missing_action == "Fill numeric missing values with median":
        numeric_cols = result.select_dtypes(include="number").columns
        for col in numeric_cols:
            if result[col].isna().any() and result[col].notna().any():
                result[col] = result[col].fillna(result[col].median())
        log["Numeric missing values"] = "Filled with column median where available"
    else:
        log["Numeric missing values"] = "Kept unchanged"
    log["Output rows"] = len(result)
    log["Output missing cells"] = int(result.isna().sum().sum())
    return result, log

def numeric_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Summary statistics for numeric columns."""
    return df.describe().transpose().reset_index(names="column")

def outlier_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Count IQR-rule potential outliers in each numeric column."""
    rows = []
    for col in df.select_dtypes(include="number").columns:
        s = df[col].dropna()
        if s.empty:
            rows.append({"column": col, "lower_fence": None, "upper_fence": None, "potential_outliers": 0})
            continue
        q1, q3 = s.quantile(.25), s.quantile(.75)
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        rows.append({"column": col, "lower_fence": round(float(low), 4),
                     "upper_fence": round(float(high), 4),
                     "potential_outliers": int(((s < low) | (s > high)).sum())})
    return pd.DataFrame(rows)
